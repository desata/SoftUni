﻿namespace VehiclesExt.Implementations
{
    public class Bus : Vehicle
    {
        public Bus(double fuelQty, double fuelConsumption, double tankCapacity) : base(fuelQty, fuelConsumption, tankCapacity)
        {
        }
    }
}
