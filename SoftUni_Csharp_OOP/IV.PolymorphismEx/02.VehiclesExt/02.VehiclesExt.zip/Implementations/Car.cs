﻿namespace VehiclesExt.Implementations
{
    public class Car : Vehicle
    {
        public Car(double fuelQty, double fuelConsumption, double tankCapacity) : base(fuelQty, fuelConsumption, tankCapacity)
        {
        }
    }
}
