﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    internal class Dog : Animal
    {

        //Dog with a single public method Bark() that prints: "barking…"



        public void Bark()
        {

            Console.WriteLine("barking…");


        }
    }
}
