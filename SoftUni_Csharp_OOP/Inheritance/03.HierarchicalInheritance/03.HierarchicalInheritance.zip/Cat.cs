﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    public class Cat : Animal
    {
        //•	Cat with a single public method Meow() that prints: "meowing…"

        public void Meow() => Console.WriteLine("meowing…");
    }
}
