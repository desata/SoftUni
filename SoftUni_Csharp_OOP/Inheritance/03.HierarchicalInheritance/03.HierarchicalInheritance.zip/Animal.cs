﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    public class Animal
    {

        public void Eat()
        {
            Console.WriteLine("eating…");
        }
        //•	Animal with a single public method Eat() that prints: "eating…"
    }
}
