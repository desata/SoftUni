﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
    
}
