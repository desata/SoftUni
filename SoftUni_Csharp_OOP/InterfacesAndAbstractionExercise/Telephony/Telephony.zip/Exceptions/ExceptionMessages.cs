﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public static class ExceptionMessages
    {
        public static string InvalidNumberException = "Invalid number!";
        public static string InvalidUrlException = "Invalid URL!";

    }
}
