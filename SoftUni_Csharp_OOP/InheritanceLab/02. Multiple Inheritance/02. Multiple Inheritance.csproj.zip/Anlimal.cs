﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    public class Anlimal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
