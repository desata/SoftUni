﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public class Warrior : Hitter
    {
        public Warrior(string name, string type, int power) : base(name, type, power)
        {
        }
    }
}
