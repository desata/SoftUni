﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public class Druid : Healer
    {
        public Druid(string name, string type, int power) : base(name, type, power)
        {

        }

       


    }
}
