﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public class Rogue : Hitter
    {
        public Rogue(string name, string type, int power) : base(name, type, power)
        {
        }
    }
}
